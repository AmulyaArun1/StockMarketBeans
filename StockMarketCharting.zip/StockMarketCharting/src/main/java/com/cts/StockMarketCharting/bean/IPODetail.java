package com.cts.StockMarketCharting.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="IPO")
@Table(name="IPO")
public class IPODetail {
	
	@Id
	private int id;
	private String companyName;
	private int stockExchange;
	private int pricePerChange;
	private int totalNumberofShares;
	private String openDateTime;
	private String remarks;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public int getStockExchange() {
		return stockExchange;
	}
	public void setStockExchange(int stockExchange) {
		this.stockExchange = stockExchange;
	}
	public int getPricePerChange() {
		return pricePerChange;
	}
	public void setPricePerChange(int pricePerChange) {
		this.pricePerChange = pricePerChange;
	}
	public int getTotalNumberofShares() {
		return totalNumberofShares;
	}
	public void setTotalNumberofShares(int totalNumberofShares) {
		this.totalNumberofShares = totalNumberofShares;
	}
	public String getOpenDateTime() {
		return openDateTime;
	}
	public void setOpenDateTime(String openDateTime) {
		this.openDateTime = openDateTime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "IPODetail [id=" + id + ", companyName=" + companyName + ", stockExchange=" + stockExchange
				+ ", pricePerChange=" + pricePerChange + ", totalNumberofShares=" + totalNumberofShares
				+ ", openDateTime=" + openDateTime + ", remarks=" + remarks + "]";
	}
	public IPODetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
