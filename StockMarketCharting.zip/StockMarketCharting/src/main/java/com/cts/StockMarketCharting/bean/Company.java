package com.cts.StockMarketCharting.bean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="Company")
@Table(name="Company")
public class Company {
	
	private String companyName;
	private long turnover;
	private String ceo;
	private String boardOfDirectors;
	private String listedinStockExchanges;
	private String sector;
	private String briefWriteup;
	@Id
	private int stockCodeinEachStockExchange;
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public long getTurnover() {
		return turnover;
	}
	public void setTurnover(long turnover) {
		this.turnover = turnover;
	}
	public String getCeo() {
		return ceo;
	}
	public void setCeo(String ceo) {
		this.ceo = ceo;
	}
	public String getBoardOfDirectors() {
		return boardOfDirectors;
	}
	public void setBoardOfDirectors(String boardOfDirectors) {
		this.boardOfDirectors = boardOfDirectors;
	}
	public String getListedinStockExchanges() {
		return listedinStockExchanges;
	}
	public void setListedinStockExchanges(String listedinStockExchanges) {
		this.listedinStockExchanges = listedinStockExchanges;
	}
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public String getBriefWriteup() {
		return briefWriteup;
	}
	public void setBriefWriteup(String briefWriteup) {
		this.briefWriteup = briefWriteup;
	}
	public int getStockCodeinEachStockExchange() {
		return stockCodeinEachStockExchange;
	}
	public void setStockCodeinEachStockExchange(int stockCodeinEachStockExchange) {
		this.stockCodeinEachStockExchange = stockCodeinEachStockExchange;
	}
	@Override
	public String toString() {
		return "Company [companyName=" + companyName + ", turnover=" + turnover + ", ceo=" + ceo + ", boardOfDirectors="
				+ boardOfDirectors + ", listedinStockExchanges=" + listedinStockExchanges + ", sector=" + sector
				+ ", briefWriteup=" + briefWriteup + ", stockCodeinEachStockExchange=" + stockCodeinEachStockExchange
				+ "]";
	}
	public Company(String companyName, long turnover, String ceo, String boardOfDirectors,
			String listedinStockExchanges, String sector, String briefWriteup, int stockCodeinEachStockExchange) {
		super();
		this.companyName = companyName;
		this.turnover = turnover;
		this.ceo = ceo;
		this.boardOfDirectors = boardOfDirectors;
		this.listedinStockExchanges = listedinStockExchanges;
		this.sector = sector;
		this.briefWriteup = briefWriteup;
		this.stockCodeinEachStockExchange = stockCodeinEachStockExchange;
	}
	public Company() {
		super();
		// TODO Auto-generated constructor stub
	}
		
	
}
